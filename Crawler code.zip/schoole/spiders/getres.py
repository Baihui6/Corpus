import scrapy
from scrapy.selector import Selector
import os
from schoole.items import SchooleItem

read_only_text = 'readonly.txt'
startlist = []
with open('url.txt', 'r') as f:
    datas = f.readlines()
    for _n in datas:
        _n = _n.replace('\n', '').replace(' ', '')
        startlist.append(_n)

# 无限获取嵌套url
class GetrSpider(scrapy.Spider):
    name = "getres"
    allowed_domains = ["ses.leeds.ac.uk"]
    start_urls = startlist

    def parse(self, response):
        try:
            self.create_link(response)
            # 获取网站的全部内容
            datas=Selector(response=response).xpath('//body//text()').extract()
            current_link = response.url.replace('https:','http:')
            item = SchooleItem()

            item['title'] = Selector(response=response).xpath('//title/text()').extract()
            item['link'] = current_link
            item['content'] = datas
            filename = self.create_and_file(response)
            # 获取所有已采集过的链接
            lock_url = self.read_use_link(read_only_text)
            if current_link not in lock_url:
                with open(filename, 'a+', encoding='utf-8') as f:
                    for res in datas:
                        _n = res.replace('\n','')
                        if _n:
                            f.write(_n + '\n')
                # 标记为已采集过的链接
                self.write_use_link(response.url,read_only_text)


            yield item
        except Exception as e:
            pass

    def create_link(self,response):
        try:
            urls=Selector(response=response).xpath('//@href').extract()
            alist = []
            for _n in urls:
                if '.css' in _n or '.ico' in _n:
                    continue
                if 'ses.leeds.ac.uk' == _n:
                    continue
                if 'ses.leeds.ac.uk' in _n:
                    alist.append(_n)

            blist = self.checkRe()
            clist = []
            with open('url.txt', 'a+') as f:
                for _n in alist:
                    if 'http' not in _n:
                        _n = 'http:' + _n
                    if _n in blist:
                        continue
                    if _n in clist:
                        continue
                    clist.append(_n)
                    self.writetxt(_n)
                    f.write(_n + '\n')
        except Exception as e:
            pass

    # 如果目录不存在就生成
    def isexists_dir_Create(self, path):
        if not os.path.exists(path):
            os.makedirs(path)

    # 根据域名创建对应的目录
    def create_and_file(self,response):
        urls = response.url.split("/")
        n = False
        link = ''
        for _k in urls[:-1]:
            # 过滤掉域名前的数据
            if 'ses.leeds.ac.uk' == _k:
                n = True
                continue
            if n:
                link += _k + '/'
        link =  link[:-1]
        if link:
            filepath = 'public/' + link
            self.isexists_dir_Create(filepath)
            return filepath + '/'+ urls[-1].replace('.php?','_').replace('=','') + '.html'
        return 'public/home.html'

    # 写入文件（去重url用）
    def writetxt(self,data):
        with open('b.txt','a+') as f:
            f.write(data + '\n')

    # 获取所有可以采集的链接
    def geturlres(self):
        alist = []
        with open('url.txt','r') as f:
            datas = f.readlines()
            for _n in datas:
                _n = _n.replace('\n','').replace(' ','')
                alist.append(_n)
        return alist

    # 读取用于去重的文件夹
    def checkRe(self):
        alist = []
        with open('b.txt','r') as f:
            datas = f.readlines()
            for _n in datas:
                _n = _n.replace('\n','').replace(' ','')
                alist.append(_n)
        return alist

    # 写入文件
    def write_use_link(self,data,filename):
        with open(filename,'a+') as f:
            f.write(data + '\n')

    # 读取文件
    def read_use_link(self,filename):
        alist = []
        with open(filename,'r') as f:
            datas = f.readlines()
            for _n in datas:
                _n = _n.replace('\n','').replace(' ','')
                alist.append(_n)
        return alist
