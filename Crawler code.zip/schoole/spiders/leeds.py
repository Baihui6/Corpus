import scrapy
from scrapy.selector import Selector


class DmozSpider(scrapy.Spider):
    name = "dmoz"
    allowed_domains = ["ses.leeds.ac.uk"]
    start_urls = [
        "https://ses.leeds.ac.uk/"
    ]

    def parse(self, response):
        urls=Selector(response=response).xpath('//@href').extract()
        alist = []
        for _n in urls:
            if '.css' in _n or '.ico' in _n:
                continue
            if '//ses.leeds.ac.uk' == _n:
                continue

            if 'ses.leeds.ac.uk' in _n:
                alist.append(_n)

        blist = self.checkRe()
        clist = []
        with open('url.txt','a+') as f:
            for _n in alist:
                if 'http' not in _n:
                    _n = 'http:' + _n
                if _n in blist:
                    continue
                if _n in clist:
                    continue
                clist.append(_n)
                self.writetxt(_n)
                f.write(_n+'\n')

    def writetxt(self,data):
        with open('b.txt','a+') as f:
            f.write(data + '\n')

    def checkRe(self):
        alist = []
        with open('b.txt','r') as f:
            datas = f.readlines()
            for _n in datas:
                _n = _n.replace('\n','').replace(' ','')
                alist.append(_n)
        return alist


